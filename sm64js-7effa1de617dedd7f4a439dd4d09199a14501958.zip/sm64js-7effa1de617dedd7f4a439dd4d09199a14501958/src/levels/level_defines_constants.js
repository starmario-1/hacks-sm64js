export const LEVEL_CASTLE_GROUNDS = 16
export const LEVEL_BOB = 9