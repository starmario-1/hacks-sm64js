class ShapeHelperGlobals {
    constructor() {
        this.gShape = {
            silverStarPtr: {},
            redStarPtr: {},
            silverSparkPtr: {},
            redSparkPtr: {}
        }
    }
}

export const ShapeHelperGlobalsInstance = new ShapeHelperGlobals()
